// Module of exports is been used

let items = []


export function additems(){
    items.push("orange","apple","grapes")}

export function countitems(){
   var t =  items.length
console.log(t)}