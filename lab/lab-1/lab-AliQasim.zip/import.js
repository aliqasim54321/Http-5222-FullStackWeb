import {additems,countitems} from "./server.js";

additems();
countitems();